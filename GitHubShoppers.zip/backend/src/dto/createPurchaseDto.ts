export interface CreatePurchaseDto {
  item_id: number;
}