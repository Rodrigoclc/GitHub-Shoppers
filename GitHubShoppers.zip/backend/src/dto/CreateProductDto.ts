export interface CreateProductDto {
  nome: string;
  preco: number;
  qtd_atual: number;
}