export interface Purchase {
  id: number;
  item_id: number;
  comprador_github_login: string;
  created_at: Date;
  updated_at: Date;
}
