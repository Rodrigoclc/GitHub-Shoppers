export interface Product {
  id: number;
  nome: string;
  preco: number;
  qtd_atual: number;
  created_at: Date;
  updated_at: Date;
}
